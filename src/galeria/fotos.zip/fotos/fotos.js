import img1 from "./1.jpg"
import img2 from "./2.jpg"
import img3 from "./3.jpg"
import img4 from "./4.jpg"
import img5 from "./5.jpg"
import img6 from "./6.jpg"


export const photos = [
    {
      src: img1,
      size: "(min-width: 36em) calc(.333 * (100vw - 12em)), 100vw",
      width: 5,
      height: 2
    },
    {
      src: img2,
      width: 3,
      height: 2
    },
    {
      src: img3,
      width: 3,
      height: 2
    },
    {
      src: "https://cdn0.bodas.net/emp/fotos/1/8/4/0/7/t40_15894842-584673431741671-9035533858770220959-n_1_18407.jpg",
      width: 7,
      height: 4
    },
    {
      src: "https://source.unsplash.com/epcsn8Ed8kY/600x799",

      width: 8,
      height: 6
    },
    {
      src: "https://source.unsplash.com/NQSWvyVRIJk/800x599",
      width: 4,
      height: 3
    },
    {
      src: "https://source.unsplash.com/zh7GEuORbUw/600x799",
      width: 3,
      height: 4
    },
    {
      src: "https://source.unsplash.com/PpOHJezOalU/800x599",
      width: 4,
      height: 3
    },
    {
      src: "https://source.unsplash.com/I1ASdgphUH4/800x599",
      width: 4,
      height: 3
    }
  ];